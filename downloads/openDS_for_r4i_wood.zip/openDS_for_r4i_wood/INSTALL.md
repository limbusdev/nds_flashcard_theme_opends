# R4i with Wood OS / Acekard

## Installation

Copy the Folder **openDS** to **SD-Card://__rpg/ui/**.
Change the theme as usual.
