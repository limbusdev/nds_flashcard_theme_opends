# How to use the loading image

The loading image must be inserted directly into the DSGAME.nds file with the **DSTWO OS: DSTWO EOS LoadingScreenModifier v0**

The program can be found on [GBATemp](https://www.gbatemp.net/) and [SuperCard Forums](http://forum.supercard.sc/thread-5581-1-1.html) or the program [DS Skin Maker](https://gbatemp.net/threads/ds-skin-maker.229246/).

***Select DSTwo** > **Tools** > **Modify Loading Screen** > **Select DSGAME.nds** > **Load** > **Apply & Backup** > **Transfer to SD-Card:/__dstwo***

Always use the original DSGAME.nds file.
