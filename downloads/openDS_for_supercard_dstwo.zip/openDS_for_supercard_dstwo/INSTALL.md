# SuperCard DSTWO

## Installation

### Step 1 (optional)

Backup the content of **SD-Card://_dstwo/plug/**.

### Step 2

Copy the folders **_dstwo** and **_dstwoplug**
to your SD-Cards root directory. Merge with
existing folders and overwrite existing files,
if necessary. The paths are correct already.
