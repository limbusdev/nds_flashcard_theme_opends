# YSMenu

## Installation

### Step 1 (Optional)

If you want to keep the default YSMenu theme for
later, create a new folder in **TTMenu**, name it 
**YSMenuThemeBackup** and move **YSMenu1.bmp**,
**YSMenu2.bmp** and **YSMENU.INI** there.

### Step 2

Copy the Folder **TTMenu** to your SD-Cards root
directory and merge any existing folders, if
necessary. Paths are correct already. Existing
**YSMenu1.bmp**, **YSMenu2.bmp** and **YSMENU.INI**
will be overwritten, if you skipped *Step 1*.
