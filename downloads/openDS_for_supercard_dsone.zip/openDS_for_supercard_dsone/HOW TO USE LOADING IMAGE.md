# How to use the loading image

The loading image must be inserted directly into the DSGAME.nds file with the **DSTWO OS: DSTWO EOS LoadingScreenModifier v0**

The program can be found on [GBATemp](https://www.gbatemp.net/) and [SuperCard Forums](http://forum.supercard.sc/) or the program [DS Skin Maker](https://gbatemp.net/threads/ds-skin-maker.229246/).

***Select DSONE** > **Tools** > **Modify Loading Screen** > **Select SCFW.SC** > **Load** > **Apply & Backup** > **Transfer to SD-Card Root***

Always use the original SCFW.SC file.
