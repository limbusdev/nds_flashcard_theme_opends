# SuperCard DSONE and DSONEi

## Installation

Copy the folder **_dsone** to your SD-Cards root
directory. Merge with existing folders. The paths
are correct already.
