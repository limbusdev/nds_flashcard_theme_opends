# openDS

openDS skin for nds flashcards is open source. The
source can be found at
[GitHub](https://github.com/gembutterfly/nds_flashcard_theme_opends/).
